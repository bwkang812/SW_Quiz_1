package org.androidtown.http;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;



/**
 * HTTP 요청 방법에 대해 알 수 있습니다.
 *
 * @author Mike
 *
 */
public class MainActivity extends ActionBarActivity {

    EditText input01;
    TextView txtMsg;
    TextView text02;



    public static String defaultUrl = "input_value";    // 초기값 네이버

    Handler handler = new Handler();                           //메인스레드와 서브스레드 간의 통신을 위해 사용

    @Override
    protected void onCreate(Bundle savedInstanceState) {  // 복원될때, savedInstanceState 정보를 가지고 자동복원.
        super.onCreate(savedInstanceState);               //OnCreate를 재정의 하여 사용하였기 때문에, super를 사용하여 상속된 클래스에서도 해당 함수 호출
        setContentView(R.layout.activity_main);           //main.xml 이라는 레이아웃을 생성하여 보여줌. xml파일안에 있는 id값들이 R.java 파일로 들어감

        input01 = (EditText) findViewById(R.id.input01);  // id 연결
        input01.setText(defaultUrl);                      // input01 에 dafaultUrl 대입

        txtMsg = (TextView) findViewById(R.id.txtMsg);   // id 연결
        text02 = (TextView) findViewById(R.id.text02);

        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat test = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String testNow = test.format(date);

        text02.setText("접속시간: "+testNow);

        // 버튼 이벤트 처리
        Button requestBtn = (Button) findViewById(R.id.requestBtn);  // id 연결
        requestBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                String value = input01.getText().toString();
                String urlStr = "http://bwkang812.godohosting.com/Test_0722.php?val="+value;

                ConnectThread thread = new ConnectThread(urlStr);           //웹으로 요청하기위해 새로 정의한 스레드 객체 생성및 시작.
                thread.start();



           }
        });
                                                                             //URL 문자열 참조.
                             //입력 상자에 입력된 URL 문자열 참조.
                String urlStr =  "http://bwkang812.godohosting.com/Test_0722.php";  //쓰레드 객체 생성, 시작
                ConnectThread thread = new ConnectThread(urlStr);           //웹으로 요청하기위해 새로 정의한 스레드 객체 생성및 시작.
                thread.start();




    }

    /**
     * 소켓 연결할 스레드 정의
     */
    class ConnectThread extends Thread {
        String urlStr;

        public ConnectThread(String inStr) {
            urlStr = inStr;
        }

        public void run() {                                                // run()  = main

            try {                                                          //request()메소드 호출
                final String output = request(urlStr);                     // final
                handler.post(new Runnable() {
                    public void run() {
                        txtMsg.setText(output);
                    }
                });

            } catch(Exception ex) {
                ex.printStackTrace();
            }

        }


        private String request(String urlStr) {
            StringBuilder output = new StringBuilder();  // 문자열을 담고, 수정할수 있다.
            try {
                URL url = new URL(urlStr);                                         // URL 객체 생성
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();   // 객체 생성 , HttpURLConncection 객체 리턴
                if (conn != null) {
                    conn.setConnectTimeout(10000);                                 // 연결 대기시간,  10000ms
                    conn.setRequestMethod("GET");                                  // GET 방식으로 요청.
                    conn.setDoInput(true);                                         //입력 가능
                    conn.setDoOutput(true);                                       //출력가능

                    int resCode = conn.getResponseCode();                            //서버에 접속하여 요청 ,웹서버에 페이지를 요청
                    if (resCode == HttpURLConnection.HTTP_OK) {                      //HTTP_OK 인 경우에는 정상적으로 응답
                        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream())) ;  //응답 결과 읽기위한 스트림 객체 생성
                        String line = null;
                        while(true) {
                            line = reader.readLine();                                   //결과 문자열에 추가. readline() : 스트림에서 한 줄씩 읽어 들이는 메소드
                            if (line == null) {
                                break;
                            }
                            output.append(line + "\n");
                        }

                        reader.close();
                        conn.disconnect();
                    }
                }
            } catch(Exception ex) {
                Log.e("SampleHTTP", "Exception in processing response.", ex);
                ex.printStackTrace();
            }

            return output.toString();
        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
